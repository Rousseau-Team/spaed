import spaed
