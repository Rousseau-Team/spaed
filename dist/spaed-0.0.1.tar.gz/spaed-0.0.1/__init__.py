from .spaed import spaed
